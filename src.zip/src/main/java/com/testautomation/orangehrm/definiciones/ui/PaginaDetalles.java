package com.testautomation.orangehrm.definiciones.ui;

public class PaginaDetalles {
}
